
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class TrouverCouleur extends JFrame implements ActionListener {

    private JLabel lTitre;
    private ButtonGroup bGCouleur1;
    private ButtonGroup bGCouleur2;
    private JRadioButton jRouge1;
    private JRadioButton jBleu1;
    private JRadioButton jJaune1;
    private JRadioButton jRouge2;
    private JRadioButton jBleu2;
    private JRadioButton jJaune2;
    private JButton jResultat;
    private JTextField tCouleurFin;
    private JPanel paneNord;
    private JPanel paneSud;
    private JPanel paneEst;
    private JPanel paneOuest;
    private JPanel paneCentre;

    public TrouverCouleur() {
        BorderLayout layout = new BorderLayout(10, 10);
        Container pane = getContentPane();
        pane.setLayout(layout);

        FlowLayout layoutN = new FlowLayout(FlowLayout.CENTER, 10, 10);
        paneNord = new JPanel();
        paneNord.setLayout(layoutN);
        lTitre = new JLabel("Trouver la résultante de couleur", JLabel.CENTER);
        paneNord.add(lTitre);
        pane.add(paneNord, BorderLayout.NORTH);

        GridLayout layoutC = new GridLayout(1, 1, 10, 10);
        paneCentre = new JPanel();
        paneCentre.setLayout(layoutC);
        tCouleurFin = new JTextField();
        tCouleurFin.setEditable(false);
        paneCentre.add(tCouleurFin);
        pane.add(paneCentre, JTextField.CENTER);

        GridLayout layoutO = new GridLayout(4, 1);
        paneOuest = new JPanel();
        paneOuest.setLayout(layoutO);
        bGCouleur1 = new ButtonGroup();
        jRouge1 = new JRadioButton("Rouge", true);
        jBleu1 = new JRadioButton("Bleu", false);
        jJaune1 = new JRadioButton("Jaune", false);
        bGCouleur1.add(jRouge1);
        bGCouleur1.add(jBleu1);
        bGCouleur1.add(jJaune1);
        paneOuest.add(jRouge1);
        paneOuest.add(jBleu1);
        paneOuest.add(jJaune1);
        pane.add(paneOuest, BorderLayout.WEST);

        GridLayout layoutE = new GridLayout(4, 1);
        paneEst = new JPanel();
        paneEst.setLayout(layoutE);
        bGCouleur2 = new ButtonGroup();
        jRouge2 = new JRadioButton("Rouge", true);
        jBleu2 = new JRadioButton("Bleu", false);
        jJaune2 = new JRadioButton("Jaune", false);
        bGCouleur2.add(jRouge2);
        bGCouleur2.add(jBleu2);
        bGCouleur2.add(jJaune2);
        paneEst.add(jRouge2);
        paneEst.add(jBleu2);
        paneEst.add(jJaune2);
        pane.add(paneEst, BorderLayout.EAST);

        FlowLayout layoutS = new FlowLayout(FlowLayout.CENTER, 10, 10);
        paneSud = new JPanel();
        paneSud.setLayout(layoutS);
        jResultat = new JButton("Couleur résultante");
        jResultat.addActionListener(this);
        paneSud.add(jResultat);
        pane.add(paneSud, BorderLayout.SOUTH);

        setSize(500, 500);
        setVisible(true);

    }

    public void actionPerformed(ActionEvent evt) {

        Object source = evt.getSource();
        if (source == jResultat) {
            findColor();
        }
    }

    public void findColor() {
        if (jRouge1.isSelected() && jRouge2.isSelected()) {
            tCouleurFin.setBackground(Color.RED);
        }
        if (jBleu1.isSelected() && jBleu2.isSelected()) {
            tCouleurFin.setBackground(Color.BLUE);
        }
        if (jBleu1.isSelected() && jJaune2.isSelected() || jBleu2.isSelected() && jJaune1.isSelected()) {
            tCouleurFin.setBackground(Color.GREEN);
        }
        if (jBleu1.isSelected() && jRouge2.isSelected() || jBleu2.isSelected() && jRouge1.isSelected()) {
            tCouleurFin.setBackground(new Color(175, 0, 200));
        }
        if (jJaune1.isSelected() && jJaune2.isSelected()) {
            tCouleurFin.setBackground(Color.YELLOW);
        }
        if (jJaune1.isSelected() && jRouge2.isSelected() || jJaune2.isSelected() && jRouge1.isSelected()) {
            tCouleurFin.setBackground(Color.ORANGE);
        }
    }
}
