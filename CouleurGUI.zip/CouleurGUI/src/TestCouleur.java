
import javax.swing.JFrame;
import com.shephertz.app42.paas.sdk.java.App42API;
import com.shephertz.app42.paas.sdk.java.ServiceAPI;
import com.shephertz.app42.paas.sdk.java.storage.StorageService;
import com.shephertz.app42.paas.sdk.java.App42Response;
import com.shephertz.app42.paas.sdk.java.App42Exception;
import com.shephertz.app42.paas.sdk.java.App42BadParameterException;
import com.shephertz.app42.paas.sdk.java.App42NotFoundException;
import com.shephertz.app42.paas.sdk.java.customcode.CustomCodeService;
import com.shephertz.app42.paas.sdk.java.user.User;
import com.shephertz.app42.paas.sdk.java.user.User.Profile;
import com.shephertz.app42.paas.sdk.java.user.User.UserGender;
import com.shephertz.app42.paas.sdk.java.user.UserService;
import java.util.ArrayList;
import java.util.Date;
import org.json.JSONException;
import org.json.JSONObject;

public class TestCouleur {

    public static void main(String args[]) throws JSONException {
        TrouverCouleur une = new TrouverCouleur();
        une.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        ArrayList<String> roleList = new ArrayList<String>();
        UserService userS = App42API.buildUserService();

        //##########################################################################
        String nameOfCustomCodeService = "Test_Custom_Code";
        String jarFilePath = "C:/Users/Olivier/Documents/NetBeansProjects/CouleurGUI/lib";
        App42API.initialize("cc03b9438a1e801bedc8f7285346f44830a74c08b198786aa079e13043eed7d9",
                "594d7b0e1fa0199ae223aac9cb65dcd69c193df0a57b31551bf24f818f0afc68");
        CustomCodeService customCodeService = App42API.buildCustomCodeService();
        String res = customCodeService.deployJarFile(nameOfCustomCodeService, jarFilePath);
        System.out.println("response is " + res);

        String name = "DEPLOYED_CUSTOM_CODE_NAME";
        JSONObject jsonBody = new JSONObject();
        jsonBody.put("Company", "Shephertz");
        /*App42API.initialize("cc03b9438a1e801bedc8f7285346f44830a74c08b198786aa079e13043eed7d9",
                "594d7b0e1fa0199ae223aac9cb65dcd69c193df0a57b31551bf24f818f0afc68");*/
        JSONObject response = customCodeService.runJavaCode(name, jsonBody);
        System.out.println("response is " + response);

        String userName = "Testing";
        String pwd = "password";
        String emailId = "biodaddy@hotmail.com";
        UserService userService = App42API.buildUserService();
        User userObj = userService.createUser(userName, pwd, emailId);
        User userAuth = userService.authenticate(userName, pwd);
        Profile profile = userObj.new Profile();
        Date date = new Date();
        profile.setFirstName("Nick");
        profile.setLastName("Gill");
        profile.setSex(UserGender.MALE);
        profile.setDateOfBirth(date);
        profile.setCity("Houston");
        profile.setState("Texas");
        profile.setPincode("74193");
        profile.setCountry("USA");
        profile.setMobile("+1-1111-111-111");
        profile.setHomeLandLine("+1-2222-222-222");
        profile.setOfficeLandLine("+1-33333-333-333");
        User user = userService.createOrUpdateProfile(userObj);
        System.out.println("userName is " + user.getUserName());
        System.out.println("firstName is " + user.getProfile().getFirstName());
        System.out.println("city is " + user.getProfile().getCity());
        System.out.println("country is " + user.getProfile().getCountry());
    }
}
